package Exceptions;

public class NegativeSalaryException extends Exception {
    public NegativeSalaryException() { super("Salary cannot be negative."); }
}


