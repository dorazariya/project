package enums;

public enum Status {
	inProcess , finished , canceled ;
}
