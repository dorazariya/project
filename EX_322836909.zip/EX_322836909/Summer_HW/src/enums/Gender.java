package enums;

public enum Gender {
	M, F 
}
