package enums;

public enum Position {
	Manager , HR , Assistance , Security ;
}
